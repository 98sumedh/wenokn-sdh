# Archive: SYNMODNCD_governorate_tau_coverage_hypertension_v7

Results of the HSA climate-health pipeline for one disease (Hypertension) and one delineation (SYNMODNCD / governorate_tau_coverage / v7). Read `manifest.json` first; every path in it is relative to the archive root.

**SYNTHETIC DATA** (SYNMOD network): these results validate the pipeline machinery and are NOT real epidemiology. Never present them as findings about Jordan.

Contents: summary tables only (no figures, no train/val/test splits, no raw datasets). Start with `out/textresults/*.md`, then open the CSV/JSON tables.
