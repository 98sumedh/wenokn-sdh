# Archive: SYNMODINF_governorate_tau_coverage_diarrheal_diseases_v7

Results of the HSA climate-health pipeline for one disease (Diarrheal Diseases) and one delineation (SYNMODINF / governorate_tau_coverage / v7). Read `manifest.json` first; every path in it is relative to the archive root.

**SYNTHETIC DATA** (SYNMOD network): these results validate the pipeline machinery and are NOT real epidemiology. Never present them as findings about Jordan.

Contents: summary tables only (no figures, no train/val/test splits, no raw datasets). Start with `out/textresults/*.md`, then open the CSV/JSON tables.
